# Sample bank files

Twelve made-up bank, card, PayPal and Venmo exports for one fictional freelancer, Alex Rivera, January to March 2026. No real person, account or transaction is in them. Each file copies the layout that bank uses for its CSV download, including the awkward parts, so TallyBee's importer can be tested without anyone's real statements.

To try them: open TallyBee's Home, upload a file, and name the account (for example "Chase Checking"). Upload all twelve to see card payments, and PayPal's withdrawals to Bank of America, pair up across accounts.

`tests/run_tests.js` imports every file and checks that each row comes in the right way round (money in or out), that card payments and PayPal withdrawals pair with their bank lines, and that a payment received on a card is never counted as income.

| File | What makes it tricky |
| --- | --- |
| chase-checking.csv | Every row ends in an extra empty column. Same-day duplicates (two subway fares) that are both real. |
| chase-credit-card.csv | Purchases are negative and payments positive. Has a return and an annual fee. |
| bank-of-america-checking.csv | A balance summary sits above the real header row. Amounts carry thousands commas. The opening-balance row has no amount. |
| bank-of-america-credit-card.csv | Reference Number and Address columns. The payee is cut off ("FEDEX OFFIC567..."). |
| wells-fargo-checking.csv | No header row at all. |
| capital-one-credit-card.csv | Separate Debit and Credit columns, dates written 2026-03-19, and a refund in Credit. |
| citi-credit-card.csv | Debit and Credit columns, with the payment as a negative credit. Its pending row is left out until it goes through. |
| american-express.csv | Purchases are positive and payments negative (the opposite of Chase). |
| discover.csv | Purchases are positive. Has a cashback reward. |
| apple-card.csv | Purchases are positive. The payment reads "ACH DEPOSIT INTERNET TRANSFER". |
| paypal.csv | Gross, Fee and Net on one row: the payment comes in whole and the fee as its own business expense. Its three withdrawals are Bank of America's "PAYPAL DES:TRANSFER" deposits, so they pair. A pending "Memo" hold is left out. |
| venmo.csv | Title lines above the header, amounts written "+ $250.00", the other person in From or To. A payment paid from a bank card brings a transfer leg; a pending payment is left out. |

Real files come only from your own bank's website, usually under Activity or Statements, then Download, then CSV. Real files hold personal data: never add one to this repository.
